from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, EmailStr
import random
import uvicorn

app = FastAPI(title="GenBank OTP Microservice")

# In-memory transient verification map cache
otp_store = {}

class OTPRequest(BaseModel):
    email: EmailStr

class OTPVerify(BaseModel):
    email: EmailStr
    otp: str

@app.post("/api/otp/generate")
def generate_otp(request: OTPRequest):
    otp = str(random.randint(100000, 999999))
    otp_store[request.email] = otp
    print("\n=============")
    print(f"[GenBank Security System] OTP for {request.email}: {otp}")
    print("=============\n")
    return {"status": "success", "message": "OTP generated successfully."}

@app.post("/api/otp/verify")
def verify_otp(request: OTPVerify):
    stored_otp = otp_store.get(request.email)
    if not stored_otp:
        raise HTTPException(status_code=400, detail="OTP expired or request not found.")
    
    if stored_otp == request.otp:
        del otp_store[request.email]  # Single-use token invalidation
        return {"status": "success", "message": "OTP verified successfully."}
    else:
        raise HTTPException(status_code=400, detail="Invalid OTP entered.")

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)