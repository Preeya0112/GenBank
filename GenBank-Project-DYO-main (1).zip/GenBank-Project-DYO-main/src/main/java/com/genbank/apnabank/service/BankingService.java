package com.genbank.apnabank.service;

import com.genbank.apnabank.model.User;
import com.genbank.apnabank.model.Admin;
import com.genbank.apnabank.repository.UserRepository;
import com.genbank.apnabank.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

@Service
public class BankingService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private AdminRepository adminRepository;

    private final String OTP_SERVICE_URL = "http://127.0.0.1:8000/api/otp";

    public User registerUser(User user) {
        String accNum = "GB" + (1000000000L + new Random().nextInt(900000000));
        user.setAccountNumber(accNum);
        user.setBalance(new BigDecimal("1000.00"));
        return userRepository.save(user);
    }

    public Optional<User> loginUser(String email, String password) {
        return userRepository.findByEmail(email).filter(u -> u.getPassword().equals(password));
    }

    public Optional<Admin> loginAdmin(String username, String password) {
        return adminRepository.findByUsername(username).filter(a -> a.getPassword().equals(password));
    }

    public void sendOtp(String email) {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, String> request = new HashMap<>();
        request.put("email", email);
        restTemplate.postForObject(OTP_SERVICE_URL + "/generate", request, Map.class);
    }

    public boolean verifyOtp(String email, String otp) {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, String> request = new HashMap<>();
        request.put("email", email);
        request.put("otp", otp);
        try {
            restTemplate.postForObject(OTP_SERVICE_URL + "/verify", request, Map.class);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}