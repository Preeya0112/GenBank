package com.genbank.apnabank.controller;

import com.genbank.apnabank.model.User;
import com.genbank.apnabank.model.Admin;
import com.genbank.apnabank.service.BankingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpSession;
import java.util.Optional;

@Controller
public class BankController {

    @Autowired
    private BankingService bankingService;

    @GetMapping("/")
    public String showIndexPage() {
        return "index";
    }

    @PostMapping("/send-otp")
    @ResponseBody
    public String handleOtpRequest(@RequestParam String email) {
        bankingService.sendOtp(email);
        return "Success";
    }

    @PostMapping("/signup")
    public String registerCustomer(@ModelAttribute User user, @RequestParam String otp, Model model) {
        boolean isOtpValid = bankingService.verifyOtp(user.getEmail(), otp);
        if (!isOtpValid) {
            model.addAttribute("error", "Invalid or Expired OTP! Registration Failed.");
            return "index";
        }
        User registered = bankingService.registerUser(user);
        model.addAttribute("message", "Account Created Successfully! Account No: " + registered.getAccountNumber());
        return "index";
    }

    @PostMapping("/user/login")
    public String userLogin(@RequestParam String email, @RequestParam String password, HttpSession session, Model model) {
        Optional<User> user = bankingService.loginUser(email, password);
        if (user.isPresent()) {
            session.setAttribute("currentUser", user.get());
            return "redirect:/user/dashboard";
        }
        model.addAttribute("error", "Invalid User Credentials.");
        return "index";
    }

    @PostMapping("/admin/login")
    public String adminLogin(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
        Optional<Admin> admin = bankingService.loginAdmin(username, password);
        if (admin.isPresent()) {
            session.setAttribute("adminUser", admin.get());
            return "redirect:/admin/dashboard";
        }
        model.addAttribute("error", "Invalid Admin Credentials.");
        return "index";
    }

    @GetMapping("/user/dashboard")
    public String showUserDashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("currentUser");
        if (user == null) return "redirect:/";
        model.addAttribute("user", user);
        return "user_dashboard";
    }

    @GetMapping("/admin/dashboard")
    public String showAdminDashboard(HttpSession session, Model model) {
        Admin admin = (Admin) session.getAttribute("adminUser");
        if (admin == null) return "redirect:/";
        model.addAttribute("admin", admin);
        return "admin_dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}