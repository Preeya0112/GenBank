package com.genbank.apnabank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenBankApplication.class, args);
	}

}
